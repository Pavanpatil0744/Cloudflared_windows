docker build -t samsurinorderonline_master_form_api .
aws ecr get-login-password --region ap-southeast-1 | docker login --username AWS --password-stdin 165887003662.dkr.ecr.ap-southeast-1.amazonaws.com
docker tag samsurinorderonline_master_form_api:latest 165887003662.dkr.ecr.ap-southeast-1.amazonaws.com/samsurinorderonline_master_form_api:latest
docker push 165887003662.dkr.ecr.ap-southeast-1.amazonaws.com/samsurinorderonline_master_form_api:latest
