use axum::{http::StatusCode, response::IntoResponse, Json};
use serde_json::json;

#[derive(Debug)]
pub enum AppError {
    InternalServerError,
    InvalidToken,
    WrongCredential,
    MissingCredential,
    TokenCreation,
    UserDoesNotExist,
    CustomBadRequestError(String),
}

impl IntoResponse for AppError {
    fn into_response(self) -> axum::response::Response {
        let custom_error: String;
        let (status, err_msg) = match self {
            Self::InternalServerError => (
                StatusCode::INTERNAL_SERVER_ERROR,
                "an internal server error occured",
            ),
            Self::InvalidToken => (StatusCode::BAD_REQUEST, "invalid token"),
            Self::MissingCredential => (StatusCode::BAD_REQUEST, "missing credential"),
            Self::TokenCreation => (StatusCode::INTERNAL_SERVER_ERROR, "failed to create token"),
            Self::WrongCredential => (StatusCode::UNAUTHORIZED, "wrong credentials"),
            Self::UserDoesNotExist => (StatusCode::UNAUTHORIZED, "User does not exist"),
            Self::CustomBadRequestError(err) => {
                custom_error = err.to_owned();
                (StatusCode::BAD_REQUEST, custom_error.as_str())
            }
        };
        (status, Json(json!({ "error": err_msg }))).into_response()
    }
}
