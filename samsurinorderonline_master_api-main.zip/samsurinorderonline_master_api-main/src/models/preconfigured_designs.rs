use serde::{Deserialize, Serialize};

#[derive(Deserialize, Serialize, sqlx::FromRow)]
pub struct Products {
    id: i64,
    productname: String,
    shortname: String,
    description: Option<String>,
    sortorder: i16,
    productname_th: Option<String>,
    producttype: i16,
}

#[derive(Deserialize, Serialize, sqlx::FromRow)]
pub struct Designs {
    designid: i32,
    designname: Option<String>,
    designname_thai: Option<String>,
    design_code: String,
    design_description: Option<String>,
    design_image_url: String,
    filter: Option<String>,
    productid: Option<i64>,
    productshortname: Option<String>,
    orderseq: Option<i32>,
}

#[derive(Deserialize, Serialize, sqlx::FromRow)]
pub struct AddDesign {
    pub designname: Option<String>,
    pub designname_thai: Option<String>,
    pub design_code: String,
    pub design_description: Option<String>,
    pub design_image_url: String,
    pub filter: Option<String>,
    pub productid: Option<i64>,
    pub productshortname: Option<String>,
    pub orderseq: Option<i32>,
}

#[derive(Deserialize, Serialize, sqlx::FromRow)]
pub struct UpdateDesign {
    pub designid: i32,
    pub designname: Option<String>,
    pub designname_thai: Option<String>,
    pub design_description: Option<String>,
    pub design_image_url: String,
    pub filter: Option<String>,
    pub orderseq: Option<i32>,
}
