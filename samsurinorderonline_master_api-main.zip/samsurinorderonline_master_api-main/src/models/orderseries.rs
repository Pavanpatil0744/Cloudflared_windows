use chrono::NaiveDate;
use serde::{Deserialize, Serialize};
use serde_json::Value;
use sqlx::FromRow;

#[derive(Serialize, Deserialize, FromRow)]
pub struct Salestrip {
    pub salestrip: String,
}

#[derive(Serialize, Deserialize, FromRow)]
pub struct Series {
    pub series: Value,
}

#[derive(Serialize, Deserialize)]
pub struct AddSeries {
    pub todate: NaiveDate,
    pub fromdate: NaiveDate,
    pub series_no: String,
    pub series_end: i64,
    pub series_start: i64,
    pub series_prefix: String,
    pub salestrip_name: String,
    pub salestrip_year: i32,
    pub usershort_names: Vec<String>,
    pub users_empcode: Vec<String>,
}

#[derive(Serialize, Deserialize, FromRow)]
pub struct Getuser {
    pub username: String,
    pub shortname: Option<String>,
    pub empcode: Option<String>,
}

#[derive(Serialize, Deserialize)]
pub struct UpdateSeries {
    pub orderseries_id: i64,
    pub users_empcode: Vec<String>,
    pub usershort_names: Vec<String>,
}

#[derive(Serialize, Deserialize, FromRow)]
pub struct Year {
    year: i64,
}
