use jsonwebtoken::{DecodingKey, EncodingKey};
use serde::{Deserialize, Serialize};

#[derive(Deserialize, sqlx::FromRow)]
pub struct User {
    pub loginid: String,
    pub password: String,
}

#[derive(Deserialize, Serialize)]
pub struct Claims {
    pub loginid: String,
    pub userid: i64,
    pub username: String,
    pub empcode: String,
    pub exp: u64,
}

pub struct Keys {
    pub encoding: EncodingKey,
    pub decoding: DecodingKey,
}

impl Keys {
    pub fn new(secret: &[u8]) -> Self {
        Self {
            encoding: EncodingKey::from_secret(secret),
            decoding: DecodingKey::from_secret(secret),
        }
    }
}
