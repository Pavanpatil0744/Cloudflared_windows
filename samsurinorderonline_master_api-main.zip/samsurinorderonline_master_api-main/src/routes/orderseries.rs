use crate::controllers::orderseries;
use axum::{
    routing::{delete, get, post, put},
    Router,
};

pub fn orderseries_routes() -> Router {
    Router::new()
        .route("/details", post(orderseries::get_orderseries_details))
        .route("/add", post(orderseries::add_orderseries_details))
        .route("/users", get(orderseries::get_users))
        .route("/update", put(orderseries::update_orderseries_details))
        .route("/delete", delete(orderseries::delete_orderseries_details))
        .route("/salestrips", get(orderseries::search_salestrips))
        .route("/years", get(orderseries::get_years))
}
