use crate::controllers::login;
use axum::{routing::post, Router};

pub fn login_routes() -> Router {
    Router::new().route("/", post(login::login))
}
