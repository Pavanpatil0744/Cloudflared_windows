use crate::controllers::preconfigured_designs::*;
use axum::{
    routing::{get, post, put},
    Router,
};

pub fn preconfigured_designs_routes() -> Router {
    Router::new()
        .route("/", get(|| async move { "Hello" }))
        .route("/products", get(search_products))
        .route(
            "/desings/by_productid/:id",
            get(get_preconfigured_designs_by_productid),
        )
        .route("/", post(save_preconfigured_design))
        .route("/", put(update_preconfigured_design))
        .route("/inactive/:id", put(delete_preconfigured_design))
}
