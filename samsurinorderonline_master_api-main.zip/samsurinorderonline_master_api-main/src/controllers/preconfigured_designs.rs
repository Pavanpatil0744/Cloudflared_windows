use axum::{extract::Path, Extension, Json};
use serde_json::{json, Value};
use sqlx::PgPool;

use crate::{
    error::AppError,
    models::{auth::Claims, preconfigured_designs::*},
};

pub async fn search_products(
    _claims: Claims,
    Extension(pg_pool): Extension<PgPool>,
) -> Result<Json<serde_json::Value>, AppError> {
    let products = sqlx::query_as::<_, Products>(
        "SELECT
                id,
                productname,
                shortname,
                description,
                sortorder,
                productname_th,
                producttype
                FROM product_m
                WHERE isactive = true AND producttype in (1, 2) ORDER BY sortorder",
    )
    .fetch_all(&pg_pool)
    .await
    .map_err(|err| {
        dbg!(err);
        AppError::InternalServerError
    })?;

    Ok(Json(json!(products)))
}

pub async fn get_preconfigured_designs_by_productid(
    _claims: Claims,
    Extension(pg_pool): Extension<PgPool>,
    Path(id): Path<i32>,
) -> Result<Json<Value>, AppError> {
    let designs = sqlx::query_as::<_, Designs>(
        "SELECT 
designid,
designname,
designname_thai,
design_code,
design_description,
design_image_url,
filter,
productid,
productshortname,
orderseq
FROM design_m_oo
WHERE productid = $1 AND is_active = true
",
    )
    .bind(id)
    .fetch_all(&pg_pool)
    .await
    .map_err(|err| {
        dbg!(err);
        AppError::InternalServerError
    })?;
    Ok(Json(json!(designs)))
}

pub async fn save_preconfigured_design(
    claims: Claims,
    Extension(pg_pool): Extension<PgPool>,
    Json(design): Json<AddDesign>,
) -> Result<Json<Value>, AppError> {
    let designs = sqlx::query_as::<_, Designs>(
        "INSERT into design_m_oo 
(designname,
designname_thai,
design_code,
design_description,
design_image_url,
filter,
productid,
productshortname,
orderseq,
created_by) VALUES
($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
RETURNING *
",
    )
    .bind(&design.designname)
    .bind(&design.designname_thai)
    .bind(&design.design_code)
    .bind(&design.design_description)
    .bind(&design.design_image_url)
    .bind(&design.filter)
    .bind(design.productid)
    .bind(&design.productshortname)
    .bind(design.orderseq)
    .bind(claims.userid)
    .fetch_one(&pg_pool)
    .await
    .map_err(|err| {
        dbg!(err);
        AppError::InternalServerError
    })?;
    Ok(Json(json!(designs)))
}

pub async fn update_preconfigured_design(
    claims: Claims,
    Extension(pg_pool): Extension<PgPool>,
    Json(design): Json<UpdateDesign>,
) -> Result<Json<Value>, AppError> {
    let designs = sqlx::query_as::<_, Designs>(
        "UPDATE design_m_oo SET
designname = $1,
designname_thai = $2,
design_description = $3,
design_image_url = $4,
filter = $5,
orderseq = $6,
updated_by = $7,
updated_at = now()::date
WHERE designid = $8
RETURNING *
",
    )
    .bind(&design.designname)
    .bind(&design.designname_thai)
    .bind(&design.design_description)
    .bind(&design.design_image_url)
    .bind(&design.filter)
    .bind(design.orderseq)
    .bind(claims.userid)
    .bind(design.designid)
    .fetch_one(&pg_pool)
    .await
    .map_err(|err| {
        dbg!(err);
        AppError::InternalServerError
    })?;
    Ok(Json(json!(designs)))
}

pub async fn delete_preconfigured_design(
    _claims: Claims,
    Extension(pg_pool): Extension<PgPool>,
    Path(id): Path<i64>,
) -> Result<Json<Value>, AppError> {
    let records = sqlx::query(
        "UPDATE
                 design_m_oo SET
                 is_active = false
                WHERE designid = $1",
    )
    .bind(id)
    .execute(&pg_pool)
    .await
    .map_err(|err| {
        dbg!(err);
        AppError::InternalServerError
    })?;
    if records.rows_affected() > 0 {
        Ok(Json(json!({"msg": "made inactive successfully"})))
    } else {
        Err(AppError::CustomBadRequestError(
            "design id is wrong!".to_owned(),
        ))
    }
}
