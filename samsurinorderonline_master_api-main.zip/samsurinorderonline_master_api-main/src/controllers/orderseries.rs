use axum::{extract::Query, Extension, Json};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sqlx::PgPool;

use crate::{
    error::AppError,
    models::{auth::*, orderseries::*},
};

pub async fn get_orderseries_details(
    _claim: Claims,
    Extension(pg_pool): Extension<PgPool>,
    Json(salestrip): Json<Salestrip>,
) -> Result<Json<Value>, AppError> {
    let salestrips = sqlx::query_as::<_, Series>(
        "SELECT 
                coalesce(jsonb_agg(osmoo), '[]'::jsonb) as series from orderseries_m_oo osmoo 
                WHERE trim(salestrip_name) = $1",
    )
    .bind(salestrip.salestrip.trim())
    .fetch_optional(&pg_pool)
    .await
    .map_err(|err| {
        dbg!(err);
        AppError::InternalServerError
    })?;
    if let Some(trip) = salestrips {
        Ok(Json(json!(trip)))
    } else {
        Err(AppError::CustomBadRequestError(
            "No orderseries for this salestrip".to_owned(),
        ))
    }
}

#[derive(Serialize, Deserialize, sqlx::FromRow)]
pub struct SeriesId {
    orderseries_id: i64,
}

pub async fn add_orderseries_details(
    _claim: Claims,
    Extension(pg_pool): Extension<PgPool>,
    Json(series): Json<AddSeries>,
) -> Result<Json<Value>, AppError> {
    let id = sqlx::query_as::<_, SeriesId>("INSERT into
            orderseries_m_oo 
            (salestrip_name, salestrip_year, series_no, series_prefix, fromdate, todate, series_start, series_end, usershort_names, users_empcode)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) 
            RETURNING orderseries_id")
        .bind(&series.salestrip_name)
        .bind(&series.salestrip_year)
        .bind(&series.series_no)
        .bind(&series.series_prefix)
        .bind(&series.fromdate)
        .bind(&series.todate)
        .bind(&series.series_start)
        .bind(&series.series_end)
        .bind(&series.usershort_names)
        .bind(&series.users_empcode)
        .fetch_one(&pg_pool)
        .await
        .map_err(|err| {
            dbg!(err);
            AppError::InternalServerError
        })?;

    let mut query = String::from(
        r#"insert into ordernumber_series_smoo ( salestrip_name, series, ordernumber, allocated_to, "year", orderseriesid ) values"#,
    );
    let (prefix, pad) = match series.series_prefix.as_str() {
        "" => ("".to_owned(), 0),
        "SO" => ("SO-".to_owned(), 0),
        "VG" => ("VG-".to_owned(), 10),
        s => (format!("{}-", s), 10),
    };
    for orn in series.series_start..=series.series_end {
        if orn != series.series_end {
            query = format!(
                "{} ( '{}', '{}', '{}{:0padding$}', null, {}, {}),",
                query,
                series.salestrip_name,
                series.series_no,
                prefix,
                orn,
                series.salestrip_year,
                id.orderseries_id,
                padding = pad
            );
        } else {
            query = format!(
                "{} ( '{}', '{}', '{}{:0padding$}', null, {}, {})",
                query,
                series.salestrip_name,
                series.series_no,
                prefix,
                orn,
                series.salestrip_year,
                id.orderseries_id,
                padding = pad
            );
        }
    }

    let res = sqlx::query(query.as_str())
        .execute(&pg_pool)
        .await
        .map_err(|err| {
            dbg!(err);
            AppError::InternalServerError
        })?;

    dbg!(res);

    Ok(Json(json!({"msg": "series added successfully"})))
}

pub async fn get_users(
    _claim: Claims,
    Extension(pg_pool): Extension<PgPool>,
) -> Result<Json<Value>, AppError> {
    let users = sqlx::query_as::<_, Getuser>(
        "SELECT 
                        username, 
                        shortname, 
                        empcode
                        FROM vguser_m vm
                        WHERE empcode 
                        IN ('E01033', 'E01431', 'E01783', 'E01218', 'E01521', 'E01693', 'EC001', 'EC005', 'EM001')",
    )
    .fetch_all(&pg_pool)
    .await
    .map_err(|err| {
        dbg!(err);
        AppError::InternalServerError
    })?;
    Ok(Json(json!(users)))
}

pub async fn update_orderseries_details(
    _claim: Claims,
    Extension(pg_pool): Extension<PgPool>,
    Json(series): Json<UpdateSeries>,
) -> Result<Json<Value>, AppError> {
    let res = sqlx::query(
        "UPDATE orderseries_m_oo
            SET 
                users_empcode = $1,
                usershort_names = $2
            WHERE
                orderseries_id = $3",
    )
    .bind(&series.users_empcode)
    .bind(&series.usershort_names)
    .bind(&series.orderseries_id)
    .execute(&pg_pool)
    .await
    .map_err(|err| {
        dbg!(err);
        AppError::InternalServerError
    })?;

    if res.rows_affected() > 0 {
        Ok(Json(json!({"msg": "updated successfully"})))
    } else {
        Err(AppError::CustomBadRequestError(
            "error during updating please check the payload".to_string(),
        ))
    }
}

#[derive(sqlx::FromRow)]
pub struct Count {
    count: i64,
}

pub async fn delete_orderseries_details(
    _claim: Claims,
    Extension(pg_pool): Extension<PgPool>,
    Query(series): Query<SeriesId>,
) -> Result<Json<Value>, AppError> {
    let count = sqlx::query_as::<_, Count>("SELECT count(*) from ordernumber_series_smoo where orderseriesid = $1 AND allocated_to IS NOT NULL ").bind(&series.orderseries_id).fetch_one(&pg_pool).await.map_err(|err| {
        dbg!(err);
        AppError::InternalServerError
    })?;
    if count.count > 0 {
        Err(AppError::CustomBadRequestError("cannot delete".to_string()))
    } else {
        let mut tx = pg_pool.begin().await.map_err(|err| {
            dbg!(err);
            AppError::InternalServerError
        })?;
        let res = sqlx::query("DELETE FROM ordernumber_series_smoo where orderseriesid = $1")
            .bind(&series.orderseries_id)
            .execute(&mut tx)
            .await
            .map_err(|err| {
                dbg!(err);
                AppError::InternalServerError
            })?;
        dbg!(res);
        let res1 = sqlx::query("DELETE FROM orderseries_m_oo where orderseries_id = $1")
            .bind(&series.orderseries_id)
            .execute(&mut tx)
            .await
            .map_err(|err| {
                dbg!(err);
                AppError::InternalServerError
            })?;
        if res1.rows_affected() > 0 {
            tx.commit().await.map_err(|err| {
                dbg!(err);
                AppError::InternalServerError
            })?;
            Ok(Json(json!({"msg": "order series deleted successfully"})))
        } else {
            tx.rollback().await.map_err(|err| {
                dbg!(err);
                AppError::InternalServerError
            })?;
            Err(AppError::CustomBadRequestError(
                "wrong order series id".to_string(),
            ))
        }
    }
}

#[derive(Serialize, Deserialize, sqlx::FromRow)]
pub struct Salestrips {
    salestrip_name: String,
    salestrip_fromdate: Option<chrono::NaiveDate>,
    salestrip_todate: Option<chrono::NaiveDate>,
    year: i64,
    has_series: Option<bool>,
}

#[derive(Serialize, Deserialize)]
pub struct SalestripYear {
    year: Option<i64>,
}

pub async fn search_salestrips(
    Extension(pg_pool): Extension<PgPool>,
    _claims: Claims,
    Query(syear): Query<SalestripYear>,
) -> Result<Json<serde_json::Value>, AppError> {
    let salestrips = sqlx::query_as::<_, Salestrips>(
        "SELECT 
                            sm.salestrip_name,
                            sm.salestrip_fromdate,
                            sm.salestrip_todate,
                            DATE_PART('year', salestrip_fromdate::date)::bigint as year,
                            case 
                            	when omo.salestrip_name is null then false
                            	else true
                            end as has_series
                            FROM salestrip_m sm
                            left join (select distinct(salestrip_name) from orderseries_m_oo) omo on omo.salestrip_name = sm.salestrip_name
                            WHERE DATE_PART('year', salestrip_fromdate::date)::bigint = $1 and sm.salestrip_source = 0
                            ORDER BY salestrip_fromdate DESC",
    )
    .bind(if let Some(year) = syear.year {
        year
    } else {
        2023
    })
    .fetch_all(&pg_pool)
    .await
    .map_err(|err| {
        dbg!(err);
        AppError::InternalServerError
    })?;
    Ok(Json(json!(salestrips)))
}

pub async fn get_years(
    Extension(pg_pool): Extension<PgPool>,
    _claims: Claims,
) -> Result<Json<serde_json::Value>, AppError> {
    let years = sqlx::query_as::<_, Year>("SELECT DISTINCT (DATE_PART('year', salestrip_fromdate::date)::bigint) as year FROM salestrip_m ORDER BY year DESC")
        .fetch_all(&pg_pool)
        .await
    .map_err(|err| {
            dbg!(err);
            AppError::InternalServerError
        })?;

    Ok(Json(json!(years)))
}
