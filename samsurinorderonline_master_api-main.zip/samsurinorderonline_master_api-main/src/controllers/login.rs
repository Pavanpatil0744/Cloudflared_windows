use axum::Json;
use serde::{Deserialize, Serialize};
use serde_json::json;

#[derive(Serialize, Deserialize, sqlx::FromRow)]
pub struct GetUser {
    userid: i64,
    username: String,
    usershortname: Option<String>,
    usertype: String,
    empcode: String,
    #[serde(skip_serializing)]
    userpassword: String,
}

use axum::Extension;
use jsonwebtoken::{encode, Header};
use serde_json::Value;
use sqlx::PgPool;

use crate::{
    error::AppError,
    models::{self, auth::Claims},
    utils::get_timestamp_hours_from_now,
    KEYS,
};

pub async fn login(
    Extension(pg_pool): Extension<PgPool>,
    Json(credentials): Json<models::auth::User>,
) -> Result<Json<Value>, AppError> {
    // check if email or password is a blank string
    if credentials.loginid.is_empty() || credentials.password.is_empty() {
        return Err(AppError::MissingCredential);
    }

    let user = sqlx::query_as::<_, GetUser>(
        "SELECT userid, shortname as usershortname, userrole as usertype, username, userpassword, empcode FROM vguser_m where empcode = $1",
    )
    .bind(&credentials.loginid)
    .fetch_optional(&pg_pool)
    .await
    .map_err(|err| {
        dbg!(err);
        AppError::InternalServerError
    })?;
    if let Some(user) = user {
        //if user exits then:
        // if password is encrypted than decode it first before comparing
        if user.userpassword != credentials.password {
            // password is incorrect
            Err(AppError::WrongCredential)
        } else {
            let claims = Claims {
                loginid: credentials.loginid.to_owned(),
                userid: user.userid,
                username: user.username.clone(),
                empcode: user.empcode.clone(),
                exp: get_timestamp_hours_from_now(10),
            };
            let token = encode(&Header::default(), &claims, &KEYS.encoding)
                .map_err(|_| AppError::TokenCreation)?;
            // return bearer token
            Ok(Json(json!({ "token": token, "user": user })))
        }
    } else {
        // if the user does not exit
        Err(AppError::UserDoesNotExist)
    }
}
