use axum::Router;

mod login;
mod orderseries;
mod preconfigured_designs;

pub fn api_routes() -> Router {
    Router::new()
        .nest("/login", login::login_routes())
        .nest("/orderseries", orderseries::orderseries_routes())
        .nest(
            "/preconfigured_designs",
            preconfigured_designs::preconfigured_designs_routes(),
        )
}
